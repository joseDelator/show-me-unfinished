# CS370---ShowMe

Team Name: Computers
Members: Jacob, Shahar Kadoch, Spencer Conley, Fabi, Nick


What does our software do?
* An easy to use customizable Concert/Event search application.
Features:
* Allow users to create their own list of favorite artists. 
   * Have api used to auto-complete artist names.
* Allow users to search events/concerts by genre.
   * Have api used to find related artists by genre.
* Users set their location, radius and optional date range, searches generate lists of all concerts/events that fit criteria.
* Allow users to connect to spotify using spotify api to retrieve data.
   * Get most played/favorite artists from the user’s profile.
* Allow users to receive notifications for newly announced events by their favorite artists.
Problem we are trying to solve:
* There are 100s of sites and apps that allow consumers to search events by simple criterias, but this also brings up random events that users have no interest in. This makes searching annoying. Our app will allow users to easily find events only for their favorite artists and in their area. This will make finding events simple and efficient, minimizing redundancy.
Where will the data come from:
* Ticketmaster, Eventbrite, seatgeek, Spotify api
Who will work on visual designs of software:
* Everyone?
 What platform will it run on:
* Android

Recap on git commands

git clone url copies an online (remote) repository to your machine

git checkout branchname switches to an existing branch

git checkout -b branchname creates a new branch, and switches to it

git add . adds all changed files to the ready-to-commit stage

git commit -m "message" commits all staged files

git push origin branchname pushes all new commits to the remote repository

Saving your work
git add . stages all your changes
git commit -m "work in progress" saves your changes
git push origin branchname uploads your changes to the remote repository
Continuing your work
If you are working on the same computer (and no one deleted your work!), you can just keep working.

If you are working on a different computer:

git clone url to clone the repository fresh If you are working on a computer that already has the project, but it's out of date:
git pull to update an existing repository
git checkout branchname to switch to your existing branch
(note: no -b here - your branch already exists)

You can now continue where you left off.

Other useful git commands
git branch displays your branches, and which one you're on

git status will show you which files are add/changed/deleted

git log will show you the history of commits to the current branch
