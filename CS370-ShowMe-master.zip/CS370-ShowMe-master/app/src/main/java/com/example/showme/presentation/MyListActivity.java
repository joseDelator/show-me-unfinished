package com.example.showme.presentation;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.showme.R;
import com.example.showme.models.EmbeddedResponseModel;
import com.example.showme.models.EventItemModel;
import com.example.showme.models.itemcards;
import com.example.showme.presentation.BaseActivity;
import com.example.showme.service.Card_adapter;
import com.example.showme.service.TicketMasterEventTask;
import java.util.ArrayList;


public class MyListActivity extends BaseActivity {
    private ArrayList<String> myExampleList;
    private Button theButton;
    private EditText artistToAdd;
    private ListView myListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_list);
        artistToAdd = findViewById(R.id.artist_textbox);
        myListView = findViewById(R.id.myListView);
        myExampleList = new ArrayList<>();
        theButton = findViewById(R.id.myListButton);
        theButton.setOnClickListener(myListButton);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, myExampleList);
        myListView.setAdapter(arrayAdapter);
    }

    View.OnClickListener myListButton = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String artist = artistToAdd.getText().toString();
            myExampleList.add(artist);
        }

    };


    @Override
    protected int getLayoutID() {
        return R.layout.activity_my_list;
    }
}