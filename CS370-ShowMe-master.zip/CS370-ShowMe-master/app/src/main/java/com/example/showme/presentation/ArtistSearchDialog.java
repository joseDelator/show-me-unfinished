package com.example.showme.presentation;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.example.showme.R;

public class ArtistSearchDialog extends AppCompatDialogFragment {
    private EditText artistSearch;
    private ArtistDialogListener artistListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder artistBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater artistInflater = getActivity().getLayoutInflater();
        View artistView = artistInflater.inflate(R.layout.searchbyartist_layout, null);
        artistBuilder.setView(artistView).setTitle("Search by Artist:")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).setPositiveButton("Search", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String artist = artistSearch.getText().toString();
                artistListener.returnArtist(artist);
            }
        });
        artistSearch = artistView.findViewById(R.id.editArtist);
        return artistBuilder.create();
    }

    public interface ArtistDialogListener {

        void returnArtist(String artist);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            artistListener = (ArtistDialogListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() +
                    "need to implement ArtistDialogListener");
        }
    }
}