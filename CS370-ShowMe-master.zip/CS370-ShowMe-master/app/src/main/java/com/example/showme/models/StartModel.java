package com.example.showme.models;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;


public class StartModel {

    private String localDate;
    private String localTime;
    private String dateTime;

    public String getLocalDate() {
        return localDate;
    }

    public String getLocalTime() {
        return localTime;
    }

    public String getDateTime() {
        ZonedDateTime date = ZonedDateTime.parse(dateTime);
        DateTimeFormatter customFormatter = DateTimeFormatter.RFC_1123_DATE_TIME;
        String newDate = date.format(customFormatter);

        return newDate;
    }
}
