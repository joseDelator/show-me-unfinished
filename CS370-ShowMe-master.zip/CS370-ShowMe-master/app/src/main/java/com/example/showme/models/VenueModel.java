package com.example.showme.models;

public class VenueModel {

    private String name;
    private String id;
    private int postalCode;


    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public int getPostalCode() {
        return postalCode;
    }
}
