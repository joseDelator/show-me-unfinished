package com.example.showme.service;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.example.showme.R;
import com.example.showme.models.EmbeddedResponseModel;
import com.example.showme.models.EventResponseModel;
import com.example.showme.network.ApiClient;
import com.example.showme.models.EventResponseModel;
import com.google.gson.Gson;

public class TicketMasterEventTask extends AsyncTask<String, Void, EventResponseModel> {
    // we should already understand how to use the Listener pattern
    private EventResponseListener listener;
    private Context context;

    public TicketMasterEventTask (Context context) {
        this.context = context;
    }

    public void setListener(EventResponseListener listener) {
        this.listener = listener;
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected EventResponseModel doInBackground(String... values) {
        // get the search term passed in on task execution
        String param = values[0];

        // build the URL for the API query string using string resources
        String queryString = new StringBuilder()
                                    .append(context.getString(R.string.base_api_url)) // base Ticket Master api
                                    .append(context.getString(R.string.discovery_route)) // route to the discovery function
                                    .append(context.getString(R.string.event_endpoint)) // endpoint for discovering events
                                    .append("?apikey=") // indicates a param being passed for the apikey
                                    .append(context.getString(R.string.api_key)) // apikey value
                                    .append("&keyword=") // indicates a param being passed for the search term
                                    .append(param).toString(); // pulled this out of 'values' (currently hardcoded to 'Madonna' in MainActivity)


        // invokes an HTTPClient to make an http call using the query string just constructed
        ApiClient client = new ApiClient();
        try {
            // get the response from the API; it's JSON, but we're reading it as a serialized string
            String response = client.getApiResponse(queryString);
            // Gson is black magic that automatically deserializes JSON domain models to Java
            // application models
            Gson gson = new Gson();
            // note the syntax for using gson - hand it a serialized JSON string and the type you
            // want it to deserialize into
            return gson.fromJson(response, EventResponseModel.class);

        } catch (Exception e) {
            Log.v("SEARCH EXCEPTION", e.getMessage());
            return null;
        }
    }

    @Override
    protected void onPostExecute(EventResponseModel eventResponseModel) {
        super.onPostExecute(eventResponseModel);
        // using the listener to send the application models to the Application/Presentation layer
        listener.onEventResponse(eventResponseModel.getEmbedded());
    }

    public interface EventResponseListener {
        void onEventResponse(EmbeddedResponseModel model);
    }
}
