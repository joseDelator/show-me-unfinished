package com.example.showme.service;

import com.example.showme.models.itemcards;

import java.util.Comparator;

public class DateComparator implements Comparator<itemcards> {
    @Override
    public int compare(itemcards o1, itemcards o2) {

        return o2.getMdate().compareTo(o1.getMdate());
    }
}