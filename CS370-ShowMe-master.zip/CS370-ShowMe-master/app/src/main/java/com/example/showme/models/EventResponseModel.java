package com.example.showme.models;

// totally stupid necessity because TicketMaster has bad API design
public class EventResponseModel {
    private EmbeddedResponseModel _embedded;

    public EmbeddedResponseModel getEmbedded() {
        return _embedded;
    }
}
