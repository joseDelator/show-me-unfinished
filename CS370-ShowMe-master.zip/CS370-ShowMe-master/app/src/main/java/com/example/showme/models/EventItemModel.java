package com.example.showme.models;

import java.util.List;

public class EventItemModel {
    private String name;
    private String id;
    private String url;
    private List<ImageModel> images;
    private DateModel dates;
    private List<VenueModel> venues;

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getUrl() {
        return url;
    }

    public List<ImageModel> getImages() {
        return images;
    }

    public DateModel getDates() {
        return dates;
    }

    public List<VenueModel> getVenues() {
        return venues;
    }
}

