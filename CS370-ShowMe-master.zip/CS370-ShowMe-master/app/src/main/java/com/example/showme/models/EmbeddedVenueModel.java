package com.example.showme.models;

import java.util.List;

public class EmbeddedVenueModel {
    private List<VenueModel> venues;

    public List<VenueModel> getVenues() {
        return venues;
    }
}
