package com.example.showme.presentation;
import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.showme.R;
import com.example.showme.models.itemcards;
import com.example.showme.presentation.BaseActivity;
import com.example.showme.service.Card_adapter;

import java.util.ArrayList;


public class FavActivity extends BaseActivity {
    public static ArrayList<itemcards> favorites = new ArrayList<>();
    private RecyclerView mRecyclerView;
    private Card_adapter mExampleAdapter;

    public void FavActivity(){
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mRecyclerView = findViewById(R.id.recyc);
        if(favorites.size() > 0) {

            mRecyclerView.setHasFixedSize(true);
            mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            mExampleAdapter = new Card_adapter(FavActivity.this, favorites);
            mRecyclerView.setAdapter(mExampleAdapter);
        }


    }

    @Override
    protected int getLayoutID() {
        return R.layout.activity_fav;
    }

    public void addFavorites(itemcards item){
        favorites.add(item);
    }
}