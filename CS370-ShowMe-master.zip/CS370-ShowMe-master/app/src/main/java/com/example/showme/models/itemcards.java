package com.example.showme.models;

public class itemcards {
    private String mimageUrl;
    private String mband;
    private String mdate;
    private String mlocation;
    private String mId;
    private String mticketmasturl;
    private float malpha;
    private boolean isFavorite;

    public itemcards(float alphaVal, String imageUrl, String band, String date, String location, String  id, String ticketmasturl) {
        malpha = alphaVal;
        mimageUrl = imageUrl;
        mband = band;
        mdate = date;
        mlocation = location;
        isFavorite = false;
        mId = id;
        mticketmasturl = ticketmasturl;
    }

    public void setFavorite(boolean favorite){
        isFavorite = favorite;
    }

    public boolean isFavorite(){
        return isFavorite;
    }

    public float getMalpha() {
        return malpha;
    }

    public String getMimageUrl() {

        return mimageUrl;
    }

    public String getMband() {

        return mband;
    }

    public String getMdate() {
        return mdate;
    }

    public String getMlocation(){
        return mlocation;
    }

    public String getMticketmasturl(){return mticketmasturl;}


    public boolean equals(itemcards item) {

        if (item.mId.equals(this.mId)) {
            return true;
        }

        if (!(item instanceof itemcards)) {
            return false;
        }

        return false;
    }


}