package com.example.showme.service;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.BounceInterpolator;
import android.view.animation.ScaleAnimation;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.showme.R;
import com.example.showme.models.itemcards;
import com.example.showme.presentation.FavActivity;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;


public class Card_adapter extends RecyclerView.Adapter<Card_adapter.cardsViewholder> {
    private Context mcontext;
    private ArrayList<itemcards> mitemlist;
    private FavActivity favorites;
    private ImageButton tickets;
    private OnItemClickListener mlistener;

    public interface OnItemClickListener{
        void onItemClick(int position );
    }

    public Card_adapter(Context context, ArrayList<itemcards> itemlist){
        mcontext = context;
        mitemlist = itemlist;

    }


    public void setOnitemClickListener(OnItemClickListener listener){
        mlistener = listener;
    }

    @NonNull
    @Override
    public cardsViewholder onCreateViewHolder( ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(mcontext).inflate(R.layout.item_card, parent, false);
        return new cardsViewholder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull cardsViewholder holder, int position) {
        holder.setViewData(mitemlist.get(position), holder.getAdapterPosition());
    }

    @Override
    public int getItemCount() {
        return mitemlist.size();
    }

    public class cardsViewholder extends RecyclerView.ViewHolder{
        public ImageView mimageView;
        public TextView mtextviewband;
        public TextView mtextviewlocation;
        public TextView mtextviewtime;
        public ImageView mfavStar;
        public ScaleAnimation scaleAnimation;
        public ToggleButton buttonFavorite;

        public boolean hasItem(itemcards item){
            for(int i = 0; i < FavActivity.favorites.size(); i++){
                if(item.equals(FavActivity.favorites.get(i))) {
                    return true;
                }
            }
            return false;
        }



        public cardsViewholder(View itemView) {
            super(itemView);
            mimageView=itemView.findViewById(R.id.band_image);
            mtextviewband=itemView.findViewById(R.id.band_name);
            mtextviewtime=itemView.findViewById(R.id.event_date);
            mtextviewlocation=itemView.findViewById(R.id.event_city);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(mlistener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            mlistener.onItemClick(position);
                        }
                    }
                }
            });

        }

        public void setViewData(final itemcards item, int adapterPosition){
            itemcards currentItem = item;
            float alphaVal = currentItem.getMalpha();
            String imageUrl = currentItem.getMimageUrl();
            String band = currentItem.getMband();
            String location = currentItem.getMlocation();
            String date = currentItem.getMdate();
            buttonFavorite=itemView.findViewById(R.id.button_favorite);
            tickets = itemView.findViewById(R.id.ticket);

            scaleAnimation = new ScaleAnimation(0.7f, 1.0f, 0.7f, 1.0f, Animation.RELATIVE_TO_SELF, 0.7f, Animation.RELATIVE_TO_SELF, 0.7f);
            scaleAnimation.setDuration(500);
            BounceInterpolator bounceInterpolator = new BounceInterpolator();
            scaleAnimation.setInterpolator(bounceInterpolator);
            buttonFavorite.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                    //animation
                    if (hasItem(item))
                    {
                        FavActivity.favorites.remove(item);
                        notifyDataSetChanged();
                    }
                    else
                    {
                        FavActivity.favorites.add(item);
                        notifyDataSetChanged();
                    }
                }

            });

            itemView.setAlpha(alphaVal);
            mtextviewtime.setText(date);
            mtextviewlocation.setText(location);
            mtextviewband.setText(band);
            if (imageUrl != "") {
                Picasso.get().load(imageUrl).fit().centerInside().into(mimageView);
            }
        }
    }
}