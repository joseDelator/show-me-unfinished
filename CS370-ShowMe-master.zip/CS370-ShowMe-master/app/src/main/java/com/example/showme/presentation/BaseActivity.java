package com.example.showme.presentation;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import com.example.showme.R;


public abstract class BaseActivity extends AppCompatActivity {

    private Button goToMyListsButton;
    private Button goToFavsButton;
    private Button goToSearchButton;
    Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutID());

        goToMyListsButton = findViewById(R.id.mylistbutton);
        goToFavsButton = findViewById(R.id.favsbutton);
        goToSearchButton = findViewById(R.id.searchbutton);

        toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);

        goToMyListsButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(BaseActivity.this, MyListActivity.class);
                startActivity(intent);
            }

        });

        goToFavsButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(BaseActivity.this, FavActivity.class);
                startActivity(intent);
            }

        });

        goToSearchButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(BaseActivity.this, MainActivity.class);
                startActivity(intent);
            }

        });

    }

    protected abstract int getLayoutID();

    }



