package com.example.showme.models;

public class DateModel {

    private String timezone;
    private StartModel start;

    public String getTimezone() {
        return timezone;
    }

    public StartModel getStartModel() {
        return start;
    }
}

