package com.example.showme.presentation;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.example.showme.R;

public class VenueSearchDialog extends AppCompatDialogFragment {

    private EditText venueSearch;
    private VenueDialogListener venueListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder venueBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater venueInflater = getActivity().getLayoutInflater();
        View venueView = venueInflater.inflate(R.layout.searchbyvenue_layout, null);
        venueBuilder.setView(venueView).setTitle("Search by Venue:")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).setPositiveButton("Search", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String venue = venueSearch.getText().toString();
                venueListener.returnVenue(venue);
            }
        });
        venueSearch = venueView.findViewById(R.id.editVenue);
        return venueBuilder.create();
    }

    public interface VenueDialogListener{
        void returnVenue(String venue);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            venueListener = (VenueDialogListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() +
                    "need to implement VenueDialogListener");
        }
    }
}