package com.example.showme.presentation;

import android.content.Intent;
import android.os.Bundle;
import android.os.Build;


import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.net.Uri;


import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.annotation.RequiresApi;

import com.example.showme.R;
import com.example.showme.models.EmbeddedResponseModel;
import com.example.showme.models.EventItemModel;
import com.example.showme.models.itemcards;
import com.example.showme.service.Card_adapter;
import com.example.showme.service.DateComparator;
import com.example.showme.service.TicketMasterEventTask;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import ru.slybeaver.slycalendarview.SlyCalendarDialog;

public class MainActivity extends BaseActivity implements AdapterView.OnItemSelectedListener, SlyCalendarDialog.Callback, ArtistSearchDialog.ArtistDialogListener,
        VenueSearchDialog.VenueDialogListener, Card_adapter.OnItemClickListener {

    private RecyclerView mRecyclerView;
    private Card_adapter mExampleAdapter;
    private ArrayList<itemcards> mExampleList;
    private ArrayList<itemcards> dateSelectedList;
    private Button apiCallButton;
    private String searchKeyword = null;
    private Spinner searchOptionSpinner;
    private Spinner sortOptionSpinner;
    private Button dateSelection;
    private Calendar firstSelection; //Used by the calendar dialog
    private Calendar secondSelection; //Used by the calendar dialog
    private String firstSelectionString;
    private String secondSelectionString;
    private String artistSearched; //Stores Artist searched in ArtistSearchDialog
    private String venueSearched; //Stores Venue searched in VenueSearchDialog
    private String json;
    private boolean isSorted;
    private ImageButton tickets;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mRecyclerView = findViewById(R.id.recyc);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mExampleList = new ArrayList<>();
        searchOptionSpinner = findViewById(R.id.search_spinner);
        sortOptionSpinner = findViewById(R.id.sort_spinner);
        dateSelectedList = new ArrayList<itemcards>();



        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.search_options, R.layout.spinner_item);
        ArrayAdapter<CharSequence> sortAdapter = ArrayAdapter.createFromResource(this, R.array.sort_options,R.layout.spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        searchOptionSpinner.setAdapter(adapter);
        sortOptionSpinner.setAdapter(sortAdapter);

        searchOptionSpinner.setOnItemSelectedListener(this);
        sortOptionSpinner.setOnItemSelectedListener(this);

        dateSelection = findViewById(R.id.dateSelection);
        dateSelection.setOnClickListener(dateButton);


        apiCallButton = findViewById(R.id.api_call_button);
        apiCallButton.setOnClickListener(searchButton);




    }

    /*Opens a dialog window with a calendar view and calls SlyCalendarDialog.Callback to retrieve
            user selected dates */

    View.OnClickListener dateButton = new View.OnClickListener(){
        @Override
        public void onClick(View v){
            new SlyCalendarDialog()
                    .setSingle(false)
                    .setFirstMonday(false)
                    .setCallback(MainActivity.this)
                    .show(getSupportFragmentManager(), "TAG_SLYCALENDAR");
        }
    };

    View.OnClickListener searchButton = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            TicketMasterEventTask task = new TicketMasterEventTask(MainActivity.this);
            task.setListener(new com.example.showme.service.TicketMasterEventTask.EventResponseListener() {
                @Override
                public void onEventResponse(EmbeddedResponseModel model) {
                    //handle result
                    float alpha;
                    int numEvents = 0;
                    String band = "";
                    String imageUrl1 = "";
                    String venue = "";
                    String date = "";
                    String id = "";
                    String tickmasterurl = "";


                    if (model == null) {
                        alpha = 0;
                        System.out.print("NO EVENTS FOUND...");
                        mExampleList.add(new itemcards(alpha, imageUrl1, band, date, venue, id, tickmasterurl));

                    } else {
                        alpha = 1;
                        numEvents = model.getEvents().size();

                        for (int i = 0; i < numEvents; i++) {

                            EventItemModel current = model.getEvents().get(i);
                            band = current.getName();
                            imageUrl1 = current.getImages().get(0).getUrl();
//                            venue = current.getVenues().get(0).getName();
                            date = current.getDates().getStartModel().getDateTime();
                            id = current.getId();
                            tickmasterurl = current.getUrl();

                            mExampleList.add(new itemcards(alpha, imageUrl1, band, date, venue, id, tickmasterurl));
                        }

                    }

                    mExampleAdapter = new Card_adapter(MainActivity.this, mExampleList);
                    mRecyclerView.setAdapter(mExampleAdapter);
                }
            });

            if (searchKeyword == null)
            {
                Toast noResult = Toast.makeText(getApplicationContext(),"No Events Found",Toast.LENGTH_SHORT);
                noResult.show();
                return;
            }
            else
            {
                task.execute(searchKeyword);
            }
        }
    };



    @Override
    public int getLayoutID()
    {
        return R.layout.activity_main;
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString(); // just used to show selected
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show(); // just used to show selected
        switch (text){
            case "Closest Distance":
                //distance stuff
                break;
            case "Closest Date":
                if (mExampleList.size() > 0) {
                    if (!isSorted) {
                        Collections.sort(mExampleList, new DateComparator());
                        this.isSorted = true;
                        ArrayAdapter<CharSequence> sortAdapter = ArrayAdapter.createFromResource(this, R.array.sort_options, R.layout.spinner_item);
                        sortOptionSpinner.setAdapter(sortAdapter);
                        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                    } else {
                        Collections.sort(mExampleList, new DateComparator().reversed());
                        this.isSorted = false;
                        ArrayAdapter<CharSequence> sortAdapter = ArrayAdapter.createFromResource(this, R.array.sort_options, R.layout.spinner_item);
                        sortOptionSpinner.setAdapter(sortAdapter);
                        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    }
                    mExampleAdapter.notifyDataSetChanged();

                }
                break;
            case "My List":
                //do My List stuff
                break;
            case "Venue":
                openVenueDialog();
                break;

            case "Artist":
                openArtistDialog();
                break;

        }

    }

    private void openArtistDialog() {
        ArtistSearchDialog artistDialog = new ArtistSearchDialog();
        artistDialog.show(getSupportFragmentManager(), "ARTIST_DIALOG");
//        EditText artistText = findViewById(R.id.editArtist);
//        searchKeyword = artistText.getText().toString();

    }

    private void openVenueDialog() {
        VenueSearchDialog venueDialog = new VenueSearchDialog();
        venueDialog.show(getSupportFragmentManager(), "VENUE_DIALOG");
//        EditText venueText = findViewById(R.id.editVenue);
//        searchKeyword = venueText.getText().toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {


    }
    @Override
    public void onCancelled() {

    }

    /*End of code for user selection on search/sort-by spinners*/

    /*Used by SlyCalendarDialog.Callback; sets firstSelected and secondSelected to user input
    from calendar dialog window.
     */
    @Override
    public void onDataSelected(Calendar firstDate, Calendar secondDate, int hours, int minutes) {
        if (firstDate != null) {
            if (secondDate == null) {
                firstDate.set(Calendar.HOUR_OF_DAY, hours);
                firstDate.set(Calendar.MINUTE, minutes);
                Toast.makeText(
                        this,
                        new SimpleDateFormat(getString(R.string.timeFormat), Locale.getDefault()).format(firstDate.getTime()),
                        Toast.LENGTH_LONG

                ).show();
                this.firstSelection = firstDate;
                ZonedDateTime date1 =
                        ZonedDateTime.ofInstant(firstSelection.toInstant(), ZoneId.systemDefault());
                DateTimeFormatter customFormatter = DateTimeFormatter.RFC_1123_DATE_TIME;
                firstSelectionString = date1.format(customFormatter);
                createDateSelectionList(firstSelectionString, secondSelectionString);

            } else {
                Toast.makeText(
                        this,
                        getString(
                                R.string.period,
                                new SimpleDateFormat(getString(R.string.dateFormat), Locale.getDefault()).format(firstDate.getTime()),
                                new SimpleDateFormat(getString(R.string.timeFormat), Locale.getDefault()).format(secondDate.getTime())
                        ),
                        Toast.LENGTH_LONG

                ).show();
                this.firstSelection = firstDate;
                this.secondSelection = secondDate;

                ZonedDateTime date1 =
                        ZonedDateTime.ofInstant(firstSelection.toInstant(), ZoneId.systemDefault());
                ZonedDateTime date2 =
                        ZonedDateTime.ofInstant(secondSelection.toInstant(), ZoneId.systemDefault());
                DateTimeFormatter customFormatter = DateTimeFormatter.RFC_1123_DATE_TIME;
                firstSelectionString = date1.format(customFormatter);
                secondSelectionString = date2.format(customFormatter);
                createDateSelectionList(firstSelectionString, secondSelectionString);


            }
        } else {
            firstDate = null;
            secondDate = null;
            mExampleAdapter = new Card_adapter(MainActivity.this, mExampleList);
            mRecyclerView.setAdapter(mExampleAdapter);
            mExampleAdapter.notifyDataSetChanged();
        }
    }
    private void createDateSelectionList(String firstSelectionString, String secondSelectionString) {

        Date eventDate;
        Date date1 = null;
        Date date2 = null;

        boolean eventsFound = false;
        dateSelectedList.clear();

        if (firstSelectionString != null) {
            date1 = convertStringToDate(firstSelectionString);;
        }
        if (secondSelectionString != null) {
            date2 = convertStringToDate(secondSelectionString);;
        }
        if (mExampleList.size() > 0) {
            for (int i = 0; i < mExampleList.size(); i++) {
                eventDate = convertStringToDate(mExampleList.get(i).getMdate().substring(0, 16));
                if (date1 != null) {
                    if (date2 == null) {
                        if (date1.getTime() == eventDate.getTime()) {
                            dateSelectedList.add(mExampleList.get(i));
                            eventsFound = true;
                        }
                    } else {
                        if ( date1.getTime() <= eventDate.getTime() && eventDate.getTime() <= date2.getTime() ){
                            if(!hasItem(mExampleList.get(i), dateSelectedList)) {
                                dateSelectedList.add(mExampleList.get(i));
                                eventsFound = true;
                            }
                        }


                    }
                }
            }
        }

        if(eventsFound && dateSelectedList.size() > 0){
            Collections.sort(dateSelectedList, new DateComparator().reversed());
            mExampleAdapter = new Card_adapter(MainActivity.this, dateSelectedList);
            mRecyclerView.setAdapter(mExampleAdapter);
            mExampleAdapter.notifyDataSetChanged();
        }else{
            Toast.makeText(this, "No dates fit the criteria", Toast.LENGTH_SHORT).show();
            dateSelectedList.clear();
            mExampleAdapter = new Card_adapter(MainActivity.this, mExampleList);
            mRecyclerView.setAdapter(mExampleAdapter);
            mExampleAdapter.notifyDataSetChanged();
        }
    }
    /*End of date retrieval code*/

    /*Code for retrieving results from an Artist or Venue Search*/
    @Override
    public void returnArtist(String artist) {
        searchKeyword = artist;
        if (searchKeyword != null)
        {
            View myView = findViewById(R.id.api_call_button);
            myView.callOnClick();
        }


    }

    @Override
    public void returnVenue(String venue) {
        searchKeyword = venue;

        if (searchKeyword != null)
        {
            View myView = findViewById(R.id.api_call_button);
            myView.callOnClick();
        }
    }
    /*End of Artist/Venue retrieval code*/
    public boolean hasItem(itemcards item, ArrayList<itemcards> list){
        for(int i = 0; i < list.size() ; i++){
            if(item.equals(list.get(i))) {
                return true;
            }
        }
        return false;
    }


    private Date convertStringToDate(String string){
        String day = string.substring(5,7).replace(" ", "");
        day.replace(" ", "");
        int dayInt = Integer.parseInt(day);
        String month = string.substring(7, 11).replace(" ", "");
        int monthInt = monthToInt(month);
        String year = string.substring(11, 16).replace(" ", "");
        int yearInt = Integer.parseInt(year);
        Date date = new GregorianCalendar(yearInt, monthInt, dayInt, 0, 0).getTime();

        return date;



    }

    private int monthToInt(String string){
        switch(string) {
            case "Jan":
                return 0;
            case "Feb":
                return 1;
            case "Mar":
                return 2;
            case "Apr":
                return 3;
            case "May":
                return 4;
            case "Jun":
                return 5;
            case "Jul":
                return 6;
            case "Aug":
                return 7;
            case "Sep":
                return 8;
            case "Oct":
                return 9;
            case "Nov":
                return 10;
            case "Dec":
                return 11;
        }
        return 12;
    }


    @Override
    public void onItemClick(int position) {
        String url;
        Intent intent = new Intent(Intent.ACTION_VIEW);
        itemcards clickeditem = mExampleList.get(position);
        url = clickeditem.getMticketmasturl();
        intent.setData((Uri.parse(url)));
        startActivity(intent);


    }
}