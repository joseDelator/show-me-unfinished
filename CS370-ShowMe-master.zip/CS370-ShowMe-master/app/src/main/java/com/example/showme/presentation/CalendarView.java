package com.example.showme.presentation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.showme.R;

import java.util.Calendar;

import ru.slybeaver.slycalendarview.SlyCalendarDialog;

public class CalendarView extends AppCompatActivity implements SlyCalendarDialog.Callback {
    Calendar firstDate;
    Calendar secondDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_view);
    }

    @Override
    public void onCancelled() {

    }

    @Override
    public void onDataSelected(Calendar firstDate, Calendar secondDate, int hours, int minutes) {
        this.firstDate = firstDate;
        this.secondDate = secondDate;
    }
}