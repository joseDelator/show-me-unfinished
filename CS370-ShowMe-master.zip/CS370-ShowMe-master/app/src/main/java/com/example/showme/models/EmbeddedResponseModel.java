package com.example.showme.models;


import java.util.List;

public class EmbeddedResponseModel {
    private List<EventItemModel> events;

    public List<EventItemModel> getEvents() {
        return events;
    }
}
