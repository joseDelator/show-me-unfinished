package com.example.showme.models;

public class ImageModel {

    private String ratio;
    private String url;
    private int width;
    private int height;

    public void setRatio(String ratio) {
        this.ratio = ratio;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public String getRatio() {
        return ratio;
    }

    public String getUrl() {
        return url;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}